package com.example.hafilaty

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
